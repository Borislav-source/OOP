# from project.bunker import Bunker
# from project.medicine.painkiller import Painkiller
# from project.medicine.salve import Salve
# from project.supply.food_supply import FoodSupply
# from project.supply.water_supply import WaterSupply
# from project.survivor import Survivor
#
# bunker = Bunker()
#
# survivor1 = Survivor('Pesho', 40)
#
# bunker.add_survivor(survivor1)
# vitamin = Salve()
# aspirin = Painkiller()
# banana = FoodSupply()
# cola = WaterSupply()
# apple = FoodSupply()
# fanta = WaterSupply()
#
# bunker.add_medicine(vitamin)
# bunker.add_medicine(aspirin)
# bunker.add_supply(banana)
# # bunker.add_supply(cola)
# bunker.add_supply(apple)
# bunker.add_supply(apple)
# # bunker.add_supply(fanta)
# # bunker.add_supply(fanta)
#
# print(len(bunker.supplies))
# print(bunker.food)
# bunker.sustain(survivor1, 'food')
# print(bunker.food)
# bunker.sustain(survivor1, 'food')
# print(bunker.food)
# bunker.sustain(survivor1, 'food')
# print(bunker.supplies)
# print(len(bunker.supplies))
# print(bunker.medicine)
# bunker.heal(survivor1, 'painkillers')
# print(bunker.medicine)
# bunker.heal(survivor1, 'salves')
# print(bunker.medicine)




# print(len(bunker.food))
# bunker.sustain(survivor1, 'food')
# # # print(bunker.take_the_last_element_of_certain_type_from_sequence_list(bunker.food, FoodSupply))
# print(len(bunker.food))
# print(len(bunker.supplies))
# print(bunker.food)
# print(bunker.supplies)
# bunker.sustain(survivor1, 'food')
# # print(bunker.food)
# bunker.sustain(survivor1, 'food')

# for f in bunker.food:
#     print(f.__class__.__name__)
# print(survivor1.needs)
# bunker.next_day()
# print(survivor1.needs)
# print(survivor1.needs_sustenance)
# survivor1.needs += 21
# print(survivor1.needs)
# print(survivor1.needs_sustenance)

# print(survivor1.name)
#
# bunker.sustain(survivor1, FoodSupply)
# print(survivor1.needs)
# survivor1.health = 50
# print(survivor1.health)
# bunker.heal(survivor1, Salve)
# print(survivor1.health)
