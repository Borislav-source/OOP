class Teacher(Employee, Person):

    @staticmethod
    def teach():
        return 'teaching...'
